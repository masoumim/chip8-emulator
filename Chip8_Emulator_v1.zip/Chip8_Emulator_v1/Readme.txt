CHIP-8 EMULATOR by Mark Masoumi
Date: April 6 2020
E-mail: masoumi.mark@gmail.com
====================================================================================

Run Chip8Emu.exe

Right-Click the window to show list of games. Click a game and enjoy!

====================================================================================
------------------
Keyboard controls:
------------------

+-+-+-+-+
|1|2|3|4|
+-+-+-+-+
|Q|W|E|R|
+-+-+-+-+
|A|S|D|F|
+-+-+-+-+
|Z|X|C|V|
+-+-+-+-+

--------------
List of games:
--------------
15PUZZLE
BLINKY
BRIX
CONNECT4
GUESS
HIDDEN
INVADERS
KALEID
MAZE
MERLIN
MISSILE
PONG
PONG2
PUZZLE
TANK
TETRIS
TICTAC
UFO
VERS
WIPEOFF

====================================================================================